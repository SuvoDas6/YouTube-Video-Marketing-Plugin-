<?php
/*
/*
Plugin Name: YouTube Pause & Contact Form Popup
Description: Embeds YouTube videos with pause-triggered Contact Form 7 popups and more feature contact Author URI .
Version: 2.3
Author: Suvo Das
Author URI: https://www.upwork.com/freelancers/~0170ba9fd6774769fa
*/

*/

if (!defined('ABSPATH')) exit;

// Enqueue assets
function ypp_enqueue_assets() {
    wp_enqueue_style('ypp-style', plugins_url('css/ypp-style.css', __FILE__));
    wp_enqueue_script('ypp-script', plugins_url('js/ypp-script.js', __FILE__), array('jquery'), '2.3', true);
    
    wp_localize_script('ypp-script', 'ypp_vars', array(
        'ajaxurl' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'ypp_enqueue_assets');

// Shortcode handler
function ypp_youtube_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => '',
        'pause_time' => 30,
        'form_id' => '',
        'width' => '100%',
        'height' => '400'
    ), $atts, 'youtube_pause_popup');

    if (empty($atts['id']) || empty($atts['form_id'])) {
        return '<p>Please provide both YouTube video ID and Contact Form 7 ID</p>';
    }

    $instance_id = 'ypp-' . uniqid();
    $form_html = do_shortcode('[contact-form-7 id="' . esc_attr($atts['form_id']) . '"]');

    ob_start(); ?>
    <div class="ypp-container" data-instance="<?php echo esc_attr($instance_id); ?>">
        <div class="ypp-video-wrapper">
            <iframe class="ypp-youtube-video" 
                    width="<?php echo esc_attr($atts['width']); ?>" 
                    height="<?php echo esc_attr($atts['height']); ?>" 
                    src="https://www.youtube.com/embed/<?php echo esc_attr($atts['id']); ?>?enablejsapi=1" 
                    frameborder="0" 
                    allowfullscreen></iframe>
        </div>
        
        <div class="ypp-popup-overlay" id="<?php echo esc_attr($instance_id); ?>-overlay">
            <div class="ypp-popup-content">
                <div class="ypp-popup-inner">
                    <?php echo $form_html; ?>
                    <button class="ypp-close-popup">×</button>
                </div>
            </div>
        </div>
        
        <input type="hidden" class="ypp-pause-time" value="<?php echo esc_attr($atts['pause_time']); ?>">
        <input type="hidden" class="ypp-instance-id" value="<?php echo esc_attr($instance_id); ?>">
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('youtube_pause_popup', 'ypp_youtube_shortcode');

// Handle AJAX form submission
add_action('wp_ajax_ypp_form_submit', 'ypp_handle_form_submission');
add_action('wp_ajax_nopriv_ypp_form_submit', 'ypp_handle_form_submission');
function ypp_handle_form_submission() {
    if (isset($_POST['_wpcf7']) && isset($_POST['instance_id'])) {
        $form_id = (int) $_POST['_wpcf7'];
        $contact_form = WPCF7_ContactForm::get_instance($form_id);
        
        if ($contact_form) {
            $result = $contact_form->validate();
            
            if ($result->is_valid()) {
                $contact_form->submit();
                wp_send_json_success(array(
                    'message' => 'Form submitted successfully',
                    'instance_id' => sanitize_text_field($_POST['instance_id'])
                ));
            } else {
                wp_send_json_error(array(
                    'message' => 'Please complete all required fields',
                    'errors' => $result->get_invalid_fields(),
                    'instance_id' => sanitize_text_field($_POST['instance_id'])
                ));
            }
        }
    }
    wp_send_json_error(array(
        'message' => 'Invalid submission',
        'instance_id' => isset($_POST['instance_id']) ? sanitize_text_field($_POST['instance_id']) : ''
    ));
}