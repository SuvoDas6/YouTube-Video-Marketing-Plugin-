jQuery(document).ready(function($) {
    // Load YouTube API
    const tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    const yppPlayers = {};
    const pauseIntervals = {};
    const formTriggered = {}; // Tracks if form has been triggered per video
    
    // YouTube API callback
    window.onYouTubeIframeAPIReady = function() {
        $('.ypp-youtube-video').each(function() {
            const $container = $(this).closest('.ypp-container');
            const instanceId = $container.data('instance');
            let playerId = $(this).attr('id');
            
            if (!playerId) {
                playerId = `ypp-player-${instanceId}`;
                $(this).attr('id', playerId);
            }
            
            yppPlayers[instanceId] = new YT.Player(playerId, {
                events: {
                    'onReady': onPlayerReady,
                    'onStateChange': onPlayerStateChange
                }
            });
            
            formTriggered[instanceId] = false; // Initialize as not triggered
        });
    };
    
    function onPlayerReady(event) {
        // Player is ready
    }
    
    function onPlayerStateChange(event) {
        const player = event.target;
        const $container = $(player.getIframe()).closest('.ypp-container');
        const instanceId = $container.data('instance');
        const pauseTime = parseInt($container.find('.ypp-pause-time').val());
        
        if (pauseIntervals[instanceId]) {
            clearInterval(pauseIntervals[instanceId]);
        }
        
        // Only trigger if playing and form hasn't been shown yet
        if (event.data === YT.PlayerState.PLAYING && !formTriggered[instanceId]) {
            pauseIntervals[instanceId] = setInterval(() => {
                const currentTime = player.getCurrentTime();
                if (currentTime >= pauseTime) {
                    clearInterval(pauseIntervals[instanceId]);
                    formTriggered[instanceId] = true; // Mark as triggered
                    player.pauseVideo();
                    
                    const $popup = $(`#${instanceId}-overlay`);
                    $popup.css('display', 'flex').hide().fadeIn(300);
                    $popup.find('.ypp-popup-content').css({
                        'opacity': 0,
                        'transform': 'translateY(20px)'
                    }).animate({
                        'opacity': 1,
                        'transform': 'translateY(0)'
                    }, 300);
                }
            }, 1000);
        }
    }
    
    // Handle form submission
    $(document).on('submit', '.ypp-popup-content form.wpcf7-form', function(e) {
        e.preventDefault();
        const $form = $(this);
        const $container = $form.closest('.ypp-container');
        const instanceId = $container.data('instance');
        const $popup = $(`#${instanceId}-overlay`);
        
        // Clear previous messages
        $form.find('.wpcf7-not-valid-tip, .wpcf7-response-output').remove();
        $form.find('.ypp-field-error').removeClass('ypp-field-error');
        
        // Set loading state
        const $submitBtn = $form.find('.wpcf7-submit');
        const originalBtnText = $submitBtn.html();
        $submitBtn
            .attr('disabled', true)
            .html('<span class="ypp-spinner"></span> Sending...');
        
        // Submit via AJAX
        $.ajax({
            url: ypp_vars.ajaxurl,
            type: 'POST',
            data: `${$form.serialize()}&action=ypp_form_submit&instance_id=${instanceId}`,
            success: (response) => {
                if (response.success) {
                    // Show success message
                    $form.html(`
                        <div class="ypp-success-message">
                            <svg class="ypp-checkmark" viewBox="0 0 52 52">
                                <circle class="ypp-checkmark-circle" cx="26" cy="26" r="25"/>
                                <path class="ypp-checkmark-check" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                            </svg>
                            <h3>Thank You!</h3>
                            <p>Your message has been sent successfully.</p>
                        </div>
                    `);
                    
                    // Close popup and resume video after delay
                    setTimeout(() => {
                        $popup.fadeOut(300, () => {
                            if (yppPlayers[instanceId]) {
                                yppPlayers[instanceId].playVideo();
                            }
                        });
                    }, 2000);
                } else {
                    // Handle validation errors
                    $submitBtn.attr('disabled', false).html(originalBtnText);
                    
                    if (response.data?.message) {
                        $form.prepend(
                            `<div class="wpcf7-response-output wpcf7-mail-failed">
                                ${response.data.message}
                            </div>`
                        );
                    }
                    
                    if (response.data?.errors) {
                        Object.entries(response.data.errors).forEach(([field, message]) => {
                            $form.find(`[name="${field}"]`)
                                .addClass('ypp-field-error')
                                .after(`<span class="wpcf7-not-valid-tip">${message}</span>`);
                        });
                    }
                }
            },
            error: () => {
                // Handle server errors
                $submitBtn.attr('disabled', false).html(originalBtnText);
                $form.prepend(`
                    <div class="wpcf7-response-output wpcf7-mail-failed">
                        There was an error submitting your form. Please try again.
                    </div>
                `);
            }
        });
    });

    // Close popup button
    $(document).on('click', '.ypp-close-popup', function() {
        const instanceId = $(this).closest('.ypp-container').data('instance');
        const $popup = $(`#${instanceId}-overlay`);
        $popup.fadeOut(300, () => {
            if (yppPlayers[instanceId]) {
                yppPlayers[instanceId].playVideo();
            }
        });
    });
    
    // Close when clicking outside popup
    $(document).on('click', '.ypp-popup-overlay', function(e) {
        if ($(e.target).hasClass('ypp-popup-overlay')) {
            const instanceId = $(this).attr('id').replace('-overlay', '');
            const $popup = $(this);
            $popup.fadeOut(300, () => {
                if (yppPlayers[instanceId]) {
                    yppPlayers[instanceId].playVideo();
                }
            });
        }
    });
    
    // Prevent closing when clicking inside popup
    $(document).on('click', '.ypp-popup-content', (e) => e.stopPropagation());
    
    // Clear errors on focus
    $(document).on('focus', '.ypp-popup-content input, .ypp-popup-content textarea', function() {
        $(this)
            .removeClass('ypp-field-error')
            .next('.wpcf7-not-valid-tip').remove()
            .closest('form')
            .find('.wpcf7-response-output').remove();
    });
});